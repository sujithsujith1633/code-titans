export default function Dashboard() {
  return <h1>Travel Planner Dashboard</h1>;
}